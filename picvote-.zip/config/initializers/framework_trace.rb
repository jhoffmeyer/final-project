module ActionDispatch
  class ExceptionWrapper
    def framework_trace
      []
    end
  end
end
