Rails.application.routes.draw do
    
  # Routes for signing up
  
  match("/test", { :controller => "polls", :action => "test", :via => "get" })
  
  match("/sign_up", { :controller => "users", :action => "registration_form", :via => "get" })

  match("/insert_user", { :controller => "users", :action => "create", :via => "post" })

    
  # Routes for signing in
  
  match("/sign_in", { :controller => "users", :action => "session_form", :via => "get" })

  match("/verify_credentials", { :controller => "users", :action => "add_cookie", :via => "post" })

  # Route for signing out

  match("/sign_out", { :controller => "users", :action => "remove_cookies", :via => "get" })

  # Homepage

  match("/", { :controller => "polls", :action => "index", :via => "get" }) 
    
  # Routes for the Users resource:  
    
  match("/users", {:controller => "users", :action => "index", :via => "get"})
    
  match("/users/:rt_username", {:controller => "users", :action => "show", :via => "get"})   
    
  match("/users/:rt_username/feed", {:controller => "users", :action => "feed", :via => "get"})
    
    

  # Routes for the Photo resource:

  # CREATE
  match("/insert_photo", { :controller => "photos", :action => "create", :via => "post"})
          
  # READ
  match("/photos", { :controller => "photos", :action => "index", :via => "get"})
  
  match("/photos/:route_photo_id", { :controller => "photos", :action => "show", :via => "get"})
  
  # UPDATE
  
  match("/modify_photo/:route_photo_id", { :controller => "photos", :action => "update", :via => "post"})
  
  # DELETE
  match("/delete_photo/:route_photo_id", { :controller => "photos", :action => "destroy", :via => "get"})

  #------------------------------

  # Routes for the Vote resource:

  # CREATE
  match("/insert_vote", { :controller => "votes", :action => "create", :via => "post"})
          
  # READ
  match("/votes", { :controller => "votes", :action => "index", :via => "get"})
  
  match("/votes/:route_vote_id", { :controller => "votes", :action => "show", :via => "get"})
  
  # UPDATE
  
  match("/modify_vote/:route_vote_id", { :controller => "votes", :action => "update", :via => "post"})
  
  # DELETE
  match("/delete_vote/:route_vote_id", { :controller => "votes", :action => "destroy", :via => "get"})

  #------------------------------

  # Routes for the Poll resource:

  # CREATE
  
  match("/new_poll", { :controller => "polls", :action => "new", :via => "get"})  
    
  match("/insert_poll", { :controller => "polls", :action => "create", :via => "post"})
          
  # READ
  match("/polls", { :controller => "polls", :action => "index", :via => "get"})
  
  match("/polls/:route_poll_id", { :controller => "polls", :action => "show", :via => "get"})
  
  # UPDATE
  
  match("/modify_poll/:route_poll_id", { :controller => "polls", :action => "update", :via => "post"})
  
  # DELETE
  match("/delete_poll/:route_poll_id", { :controller => "polls", :action => "destroy", :via => "get"})

  #------------------------------

  devise_for :admin_users, ActiveAdmin::Devise.config
  ActiveAdmin.routes(self)
end
