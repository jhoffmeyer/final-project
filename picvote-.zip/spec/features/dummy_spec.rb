require "rails_helper"

describe "This project" do
  it "has no specs — it's up to you to write some, if you want to!" do
    expect(1).to eq(1)
  end
end
