# == Schema Information
#
# Table name: photos
#
#  id         :integer          not null, primary key
#  image      :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Photo < ApplicationRecord
        
    
mount_uploader :image, ImageUploader    
    
has_many :votes, :dependent => :destroy
has_many :images1s, :dependent => :destroy
has_many :images2s, :dependent => :destroy
    
end
