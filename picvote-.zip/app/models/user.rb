# == Schema Information
#
# Table name: users
#
#  id              :integer          not null, primary key
#  username        :string
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  password_digest :string
#

class User < ApplicationRecord
    has_secure_password
    
      validates(:username,
    { 
      :presence => true, 
      :uniqueness => { :case_sensitive => false } 
    }
  )
    
has_many :likes, :class_name => "Vote", :dependent => :destroy
has_many :sent_follow_requests, :class_name => "FollowRequest", :foreign_key => "sender_id", :dependent => :destroy
has_many :received_follow_requests, :class_name => "FollowRequest", :foreign_key => "recipient_id", :dependent => :destroy
has_many :own_polls, :class_name => "Poll", :foreign_key => "owner_id", :dependent => :destroy
    
has_many :following, :through => :sent_follow_requests, :source => :recipient
has_many :followers, :through => :received_follow_requests, :source => :sender
has_many :liked_photos, :through => :likes, :source => :poll
has_many :feed, :through => :following, :source => :own_photos
has_many :activity, :through => :following, :source => :liked_photos
    
validates :username, :presence => true
validates :username, :uniqueness => true
    
    

end
