class VotesController < ApplicationController
  def index
    @votes = Vote.all.order({ :created_at => :desc })
    
    respond_to do |format|
      format.json do
        render({ :json => @votes.as_json })
      end

      format.html do
        render({ :template => "votes/index.html.erb" })
      end
    end
  end

  def show
    the_id = params.fetch(:route_vote_id)
    @vote = Vote.where({:id => the_id }).first

    respond_to do |format|
      format.json do
        render({ :json => @vote.as_json })
      end

      format.html do
        render({ :template => "votes/show.html.erb" })
      end
    end
  end

  def create
    @vote = Vote.new

    @vote.user_id = current_user.id
    @vote.poll_id = params.fetch(:qs_poll_id, nil)
    @vote.selection1 = params.fetch(:qs_selection1, 0)
    @vote.selection2 = params.fetch(:qs_selection2, 0)  
      
    if @vote.valid?
      @vote.save
      respond_to do |format|
        format.json do
          render({ :json => @vote.as_json })
        end
  
        format.html do
          redirect_to("/polls", { :notice => "You Voted!"})
        end
      end

    else
      respond_to do |format|
        format.json do
          render({ :json => @vote.as_json })
        end
  
        format.html do
          redirect_to("/polls", { :notice => "Vote failed to create successfully."})
        end
      end
    end
  end

  def update
    the_id = params.fetch(:route_vote_id)
    @vote = Vote.where(:id => the_id).at(0)
    @vote.selection1 = params.fetch(:qs_selection1, 0)
    @vote.selection2 = params.fetch(:qs_selection2, 0)


    if @vote.valid?
      @vote.save
      respond_to do |format|
        format.json do
          render({ :json => @vote.as_json })
        end
  
        format.html do
          redirect_to("/polls", {:notice => "Vote Changed!"})
        end
      end
    else
      # render({:template => "/votes/edit_form_with_errors.html.erb"})
      respond_to do |format|
        format.json do
          render({ :json => @vote.as_json })
        end
  
        format.html do
          render({ :template => "polls/index.html.erb" })
        end
      end
    end
  end

  def destroy
    the_id = params.fetch(:route_vote_id)
    @vote = Vote.where({ :id => the_id }).first

    @vote.destroy

    respond_to do |format|
      format.json do
        render({ :json => @vote.as_json })
      end

      format.html do
        redirect_to("/polls", {:notice => "Vote Removed"})
      end
    end
  end
end
