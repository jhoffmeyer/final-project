class PhotosController < ApplicationController
  def index
    @photos = Photo.all.order({ :created_at => :desc })
    
    respond_to do |format|
      format.json do
        render({ :json => @photos.as_json })
      end

      format.html do
        render({ :template => "photos/index.html.erb" })
      end
    end
  end

  def show
    the_id = params.fetch(:route_photo_id)
    @photo = Photo.where({:id => the_id }).first

    respond_to do |format|
      format.json do
        render({ :json => @photo.as_json })
      end

      format.html do
        render({ :template => "photos/show.html.erb" })
      end
    end
  end

  def create
    @photo = Photo.new

    @photo.image = params.fetch(:image, nil)

    if @photo.valid?
      @photo.save
      respond_to do |format|
        format.json do
          render({ :json => @photo.as_json })
        end
  
        format.html do
          redirect_to("/new_poll", { :notice => "Photo created successfully."})
        end
      end

    else
      respond_to do |format|
        format.json do
          render({ :json => @photo.as_json })
        end
  
        format.html do
          redirect_to("/new_poll", { :notice => "Photo failed to create successfully."})
        end
      end
    end
  end

  def update
    the_id = params.fetch(:route_photo_id)
    @photo = Photo.where(:id => the_id).at(0)


    @photo.image = params.fetch(:image, @photo.image)


    if @photo.valid?
      @photo.save
      respond_to do |format|
        format.json do
          render({ :json => @photo.as_json })
        end
  
        format.html do
          redirect_to("/photos/#{@photo.id}", {:notice => "Photo updated successfully."})
        end
      end
    else
      # render({:template => "/photos/edit_form_with_errors.html.erb"})
      respond_to do |format|
        format.json do
          render({ :json => @photo.as_json })
        end
  
        format.html do
          render({ :template => "photos/show.html.erb" })
        end
      end
    end
  end

  def destroy
    the_id = params.fetch(:route_photo_id)
    @photo = Photo.where({ :id => the_id }).first

    @photo.destroy

    respond_to do |format|
      format.json do
        render({ :json => @photo.as_json })
      end

      format.html do
        redirect_to("/photos", {:notice => "Photo deleted successfully."})
      end
    end
  end
end
