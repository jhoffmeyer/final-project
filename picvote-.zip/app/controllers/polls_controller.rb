class PollsController < ApplicationController
  def index
    @polls = Poll.all.order({ :created_at => :desc })
    
    respond_to do |format|
      format.json do
        render({ :json => @polls.as_json })
      end

      format.html do
        render({ :template => "polls/index.html.erb" })
      end
    end
  end

  def show
    the_id = params.fetch(:route_poll_id)
    @poll = Poll.where({:id => the_id }).first

    respond_to do |format|
      format.json do
        render({ :json => @poll.as_json })
      end

      format.html do
        render({ :template => "polls/show.html.erb" })
      end
    end
  end
    
  def new  
      
      respond_to do |format|
      format.json do
        render({ :json => @polls.as_json })
      end
      
      format.html do
        render({ :template => "polls/new.html.erb" })
      end
    end  
  end    
      
  def create
    @poll = Poll.new
    @poll.caption = params.fetch(:caption, nil)
    @poll.owner_id = current_user.id
    @poll.image1 = params.fetch(:image1, nil)
    @poll.image2 = params.fetch(:image2, nil)

    if @poll.valid?
        
        
      @poll.save
      respond_to do |format|
        format.json do
          render({ :json => @poll.as_json })
        end
  
        format.html do
          redirect_to("/polls", { :notice => "Poll created successfully."})
        end
      end

    else
     respond_to do |format|
        format.json do
          render({ :json => @poll.as_json })
        end
  
        format.html do
          redirect_to("/polls", { :notice => "Poll failed to create successfully."})
        end
       end
     end
  end

  def update
    the_id = params.fetch(:route_poll_id)
    @poll = Poll.where(:id => the_id).at(0)


    @poll.caption = params.fetch(:caption, @poll.caption)


    @poll.owner_id = params.fetch(:owner_id, @poll.owner_id)


    @poll.location = params.fetch(:location, @poll.location)


    @poll.image1 = params.fetch(:image1, @poll.image1)


    @poll.image2 = params.fetch(:image2, @poll.image2)


    if @poll.valid?
      @poll.save
      respond_to do |format|
        format.json do
          render({ :json => @poll.as_json })
        end
  
        format.html do
          redirect_to("/polls/#{@poll.id}", {:notice => "Poll updated successfully."})
        end
      end
    else
      # render({:template => "/polls/edit_form_with_errors.html.erb"})
      respond_to do |format|
        format.json do
          render({ :json => @poll.as_json })
        end
  
        format.html do
          render({ :template => "polls/show.html.erb" })
        end
      end
    end
  end

  def destroy
    the_id = params.fetch(:route_poll_id)
    @poll = Poll.where({ :id => the_id }).first

    @poll.destroy

    respond_to do |format|
      format.json do
        render({ :json => @poll.as_json })
      end

      format.html do
        redirect_to("/polls", {:notice => "Poll deleted successfully."})
      end
    end
  end

  def test

    @poll = Poll.all.last
      
    respond_to do |format|
      format.json do
        render({ :json => @poll.as_json })
      end

      format.html do
        render({ :template => "polls/test.html.erb" })
      end
    end
  end  

end
