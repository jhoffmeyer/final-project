class CreateImages2s < ActiveRecord::Migration[5.1]
  def change
    create_table :images2s do |t|
      t.integer :photo_id

      t.timestamps
    end
  end
end
