class VoteChange < ActiveRecord::Migration[5.1]
  def change
      
      add_column :votes, :selection, :integer
      remove_column :votes, :photo_id
      
  end
end
