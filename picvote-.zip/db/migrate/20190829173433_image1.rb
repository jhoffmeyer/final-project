class Image1 < ActiveRecord::Migration[5.1]
  def change
      
      add_column :polls, :image1, :string
      remove_column :polls, :images1_id
      
  end
end
