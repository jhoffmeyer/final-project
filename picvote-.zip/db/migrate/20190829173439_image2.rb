class Image2 < ActiveRecord::Migration[5.1]
  def change
       
      add_column :polls, :image2, :string
      remove_column :polls, :images2_id
       
  end
end
