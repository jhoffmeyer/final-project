class CreatePolls < ActiveRecord::Migration[5.1]
  def change
    create_table :polls do |t|
      t.string :caption
      t.integer :owner_id
      t.string :location
      t.integer :images1_id
      t.integer :images2_id

      t.timestamps
    end
  end
end
