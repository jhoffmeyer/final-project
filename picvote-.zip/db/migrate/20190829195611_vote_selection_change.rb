class VoteSelectionChange < ActiveRecord::Migration[5.1]
  def change
 
      add_column :votes, :selection1, :integer
      add_column :votes, :selection2, :integer
      remove_column :votes, :selection
  
  end
end
